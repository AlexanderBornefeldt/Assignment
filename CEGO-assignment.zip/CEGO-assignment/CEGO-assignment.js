/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


const mysql = require('mysql');
// Requiring fs module in which 
// writeFile function is defined. 
const fs = require('fs');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'CEGO'
});

// Connect to the database:
connection.connect((err) => {
  if (err) throw err;
  console.log('Connected!');
});


// Add unique identifier to column "id" to ensure data integrity and avoid future duplicates.
queryDatabase("ALTER TABLE users ADD PRIMARY KEY (id)");

// Check for duplicates in current data:
queryDatabase("SELECT id, firstName, lastName, email, COUNT(*) occurrences FROM users GROUP BY id HAVING COUNT(*) > 1");

// Read table, create .txt file and add data:
readAndWriteToFile("SELECT * FROM users", "Output.txt");


// Delete the data from the database:
queryDatabase("DELETE FROM users");



function queryDatabase( query ) {
    connection.query( query );
}

function readAndWriteToFile( query, fileName ) {
  // Read data from the database on table "users":
connection.query( query, function (err, rows) {
  if(err) throw err;


// Write data from the table to a local file: 
    fs.writeFile(fileName, JSON.stringify(rows), (err) => { 
        if (err) throw err; 
}); 
});  
}

